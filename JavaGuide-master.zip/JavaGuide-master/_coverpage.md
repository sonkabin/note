<p align="center">
<img src="https://my-blog-to-use.oss-cn-beijing.aliyuncs.com/2019-3logo-透明.png" width=""/>
</p>

<h1 align="center">Java 学习/面试指南</h1>

[常用资源](https://shimo.im/docs/MuiACIg1HlYfVxrj/)
[GitHub](<https://github.com/Snailclimb/JavaGuide>)
[开始阅读](#java)

![](./media/pictures/rostyslav-savchyn-5joK905gcGc-unsplash.jpg)


